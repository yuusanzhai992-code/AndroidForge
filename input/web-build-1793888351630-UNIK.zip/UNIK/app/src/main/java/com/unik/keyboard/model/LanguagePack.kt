package com.unik.keyboard.model

data class LanguagePack(
    val id: String,
    val name: String,
    val nativeName: String,
    val direction: String,
    val script: String,
    val rows: List<List<String>>,
    val mapping: Map<String, String>
)