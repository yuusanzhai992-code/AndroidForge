package com.unik.keyboard.engine

import com.unik.keyboard.model.LanguagePack

object InputEngine {

    // キー入力を言語パックに対応した文字へ変換
    fun convert(
        pack: LanguagePack,
        key: String
    ): String {
        return pack.mapping[key] ?: key
    }

    // 特殊キーの判定
    fun isSpecialKey(key: String): Boolean {
        return key in listOf(
            "⌫",
            "↵",
            "space",
            "🌐",
            "⇧",
            "?123"
        )
    }

    // 入力文字の変換
    fun process(
        pack: LanguagePack,
        input: String
    ): String {
        return input.map { char ->
            convert(pack, char.toString())
        }.joinToString("")
    }

    // 大文字・小文字の切り替え
    fun toggleCase(
        key: String,
        uppercase: Boolean
    ): String {
        return if (uppercase) {
            key.uppercase()
        } else {
            key.lowercase()
        }
    }
}