package com.unik.keyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "UNIK"
            textSize = 32f
            gravity = Gravity.CENTER
        }

        val description = TextView(this).apply {
            text = "Universal Language Keyboard\n\n"
            textSize = 16f
            gravity = Gravity.CENTER
        }

        val settingsButton = Button(this).apply {
            text = "キーボード設定を開く"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        val selectButton = Button(this).apply {
            text = "UNIKを有効化"
            setOnClickListener {
                val imm = getSystemService(
                    Context.INPUT_METHOD_SERVICE
                ) as InputMethodManager

                imm.showInputMethodPicker()
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(settingsButton)
        layout.addView(selectButton)

        setContentView(layout)
    }
}