package com.unik.keyboard.data

import android.content.Context
import com.unik.keyboard.model.LanguagePack
import org.json.JSONObject
import org.json.JSONArray
import java.io.File

class LanguageRepository(private val context: Context) {

    private val languageDirectory =
        File(context.filesDir, "languages")

    init {
        if (!languageDirectory.exists()) {
            languageDirectory.mkdirs()
        }

        createDefaultLanguage()
    }

    fun getDefaultLanguage(): LanguagePack {
        val file = File(languageDirectory, "english.json")

        if (!file.exists()) {
            createDefaultLanguage()
        }

        return loadLanguage(file)
    }

    fun getAllLanguages(): List<LanguagePack> {
        return languageDirectory.listFiles()
            ?.filter { it.extension == "json" }
            ?.mapNotNull {
                try {
                    loadLanguage(it)
                } catch (e: Exception) {
                    null
                }
            } ?: emptyList()
    }

    fun importLanguage(file: File): Boolean {
        return try {
            val pack = loadLanguage(file)

            val destination = File(
                languageDirectory,
                "${pack.id}.json"
            )

            file.copyTo(destination, overwrite = true)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun loadLanguage(file: File): LanguagePack {
        val json = JSONObject(file.readText())

        val rowsJson = json.getJSONArray("rows")
        val rows = mutableListOf<List<String>>()

        for (i in 0 until rowsJson.length()) {
            val rowJson = rowsJson.getJSONArray(i)
            val row = mutableListOf<String>()

            for (j in 0 until rowJson.length()) {
                row.add(rowJson.getString(j))
            }

            rows.add(row)
        }

        val mappingJson = json.optJSONObject("mapping")
            ?: JSONObject()

        val mapping = mutableMapOf<String, String>()

        val keys = mappingJson.keys()

        while (keys.hasNext()) {
            val key = keys.next()
            mapping[key] = mappingJson.getString(key)
        }

        return LanguagePack(
            id = json.getString("id"),
            name = json.getString("name"),
            nativeName = json.getString("nativeName"),
            direction = json.optString("direction", "ltr"),
            script = json.optString("script", "unknown"),
            rows = rows,
            mapping = mapping
        )
    }

    private fun createDefaultLanguage() {
        val file = File(languageDirectory, "english.json")

        if (file.exists()) return

        val json = """
        {
          "id": "english",
          "name": "English",
          "nativeName": "English",
          "direction": "ltr",
          "script": "Latin",
          "rows": [
            ["q","w","e","r","t","y","u","i","o","p"],
            ["a","s","d","f","g","h","j","k","l"],
            ["⇧","z","x","c","v","b","n","m","⌫"],
            ["?123","🌐","space","↵"]
          ],
          "mapping": {}
        }
        """.trimIndent()

        file.writeText(json)
    }
}