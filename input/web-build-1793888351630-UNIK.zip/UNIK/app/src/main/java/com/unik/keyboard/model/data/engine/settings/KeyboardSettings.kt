package com.unik.keyboard.settings

import android.content.Context
import android.graphics.Color

data class KeyboardSettings(

    val keyColor: Int = Color.rgb(55, 55, 65),

    val textColor: Int = Color.WHITE,

    val backgroundColor: Int = Color.rgb(30, 30, 38),

    val textSize: Float = 18f,

    val keyHeight: Int = 55,

    val cornerRadius: Float = 12f,

    val vibration: Boolean = true,

    val sound: Boolean = false
) {

    companion object {

        private const val PREF_NAME = "unik_settings"

        fun load(context: Context): KeyboardSettings {

            val prefs = context.getSharedPreferences(
                PREF_NAME,
                Context.MODE_PRIVATE
            )

            return KeyboardSettings(

                keyColor = prefs.getInt(
                    "keyColor",
                    Color.rgb(55, 55, 65)
                ),

                textColor = prefs.getInt(
                    "textColor",
                    Color.WHITE
                ),

                backgroundColor = prefs.getInt(
                    "backgroundColor",
                    Color.rgb(30, 30, 38)
                ),

                textSize = prefs.getFloat(
                    "textSize",
                    18f
                ),

                keyHeight = prefs.getInt(
                    "keyHeight",
                    55
                ),

                cornerRadius = prefs.getFloat(
                    "cornerRadius",
                    12f
                ),

                vibration = prefs.getBoolean(
                    "vibration",
                    true
                ),

                sound = prefs.getBoolean(
                    "sound",
                    false
                )
            )
        }

        fun save(
            context: Context,
            settings: KeyboardSettings
        ) {

            val prefs = context.getSharedPreferences(
                PREF_NAME,
                Context.MODE_PRIVATE
            )

            prefs.edit().apply {

                putInt("keyColor", settings.keyColor)

                putInt("textColor", settings.textColor)

                putInt(
                    "backgroundColor",
                    settings.backgroundColor
                )

                putFloat("textSize", settings.textSize)

                putInt("keyHeight", settings.keyHeight)

                putFloat(
                    "cornerRadius",
                    settings.cornerRadius
                )

                putBoolean("vibration", settings.vibration)

                putBoolean("sound", settings.sound)

                apply()
            }
        }
    }
}