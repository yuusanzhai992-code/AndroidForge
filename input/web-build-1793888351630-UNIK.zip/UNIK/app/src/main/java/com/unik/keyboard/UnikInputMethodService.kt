package com.unik.keyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.Button
import android.widget.Toast

import com.unik.keyboard.engine.RenderEngine
import com.unik.keyboard.data.LanguageRepository

class UnikInputMethodService : InputMethodService() {

    private lateinit var repository: LanguageRepository

    override fun onCreate() {
        super.onCreate()
        repository = LanguageRepository(this)
    }

    override fun onCreateInputView(): View {

        val pack = repository.getDefaultLanguage()

        return RenderEngine.render(
            this,
            pack
        ) { key ->
            handleKey(key)
        }
    }

    private fun handleKey(key: String) {

        val connection: InputConnection =
            currentInputConnection ?: return

        when (key) {

            "⌫" -> {
                connection.deleteSurroundingText(1, 0)
            }

            "↵" -> {
                connection.commitText("\n", 1)
            }

            "space" -> {
                connection.commitText(" ", 1)
            }

            "🌐" -> {
                switchToNextInputMethod(false)
            }

            else -> {
                connection.commitText(key, 1)
            }
        }
    }
}