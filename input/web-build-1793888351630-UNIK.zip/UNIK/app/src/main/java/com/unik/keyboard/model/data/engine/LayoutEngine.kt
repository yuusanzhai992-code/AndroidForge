package com.unik.keyboard.engine

import com.unik.keyboard.model.LanguagePack

object LayoutEngine {

    // 言語パックからキーボード配列を取得
    fun getRows(pack: LanguagePack): List<List<String>> {
        return pack.rows.filter { row ->
            row.isNotEmpty()
        }
    }

    // キーの数を取得
    fun getKeyCount(pack: LanguagePack): Int {
        return getRows(pack).sumOf { it.size }
    }

    // キーが存在するか確認
    fun containsKey(pack: LanguagePack, key: String): Boolean {
        return getRows(pack).any { row ->
            key in row
        }
    }

    // 言語の文字方向を取得
    fun isRightToLeft(pack: LanguagePack): Boolean {
        return pack.direction.equals("rtl", ignoreCase = true)
    }
}