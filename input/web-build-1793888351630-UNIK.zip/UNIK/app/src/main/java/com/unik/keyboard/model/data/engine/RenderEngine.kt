package com.unik.keyboard.engine

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout

import com.unik.keyboard.model.LanguagePack
import com.unik.keyboard.settings.KeyboardSettings

object RenderEngine {

    fun render(
        context: Context,
        pack: LanguagePack,
        onKeyPressed: (String) -> Unit
    ): View {

        val settings = KeyboardSettings.load(context)

        val keyboard = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 6)
            layoutDirection = if (LayoutEngine.isRightToLeft(pack)) {
                View.LAYOUT_DIRECTION_RTL
            } else {
                View.LAYOUT_DIRECTION_LTR
            }
        }

        val rows = LayoutEngine.getRows(pack)

        rows.forEach { rowKeys ->

            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }

            rowKeys.forEach { keyText ->

                val button = Button(context).apply {
                    text = keyText
                    textSize = settings.textSize
                    setTextColor(settings.textColor)
                    isAllCaps = false
                    typeface = Typeface.DEFAULT

                    background = GradientDrawable().apply {
                        setColor(settings.keyColor)
                        cornerRadius = settings.cornerRadius
                    }

                    setOnClickListener {
                        onKeyPressed(keyText)
                    }

                    layoutParams = LinearLayout.LayoutParams(
                        0,
                        settings.keyHeight,
                        1f
                    ).apply {
                        setMargins(3, 3, 3, 3)
                    }
                }

                row.addView(button)
            }

            keyboard.addView(
                row,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        return keyboard
    }
}